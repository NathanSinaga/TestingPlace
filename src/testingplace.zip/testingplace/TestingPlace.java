/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testingplace;

/**
 *
 * @author Nathan Sinaga
 */
public class TestingPlace {

    public static void printAll(DaftarMerk DM){
        DaftarKendaraan temp = DM.head;
        Kendaraan tempK;
        while(temp != null){
            tempK = temp.head;
            System.out.println(temp.merk);
            while(tempK != null){
                System.out.println(tempK.model);
                tempK = tempK.next;
            }
            temp = temp.next;
            System.out.println();
        }
    }
    public static void main(String[] args) {
        DaftarMerk daftarMerk = new DaftarMerk();
        DaftarKendaraan Toyota = new DaftarKendaraan("Toyota");
        DaftarKendaraan Mercedes = new DaftarKendaraan("Mercedes");
        DaftarKendaraan Wuling = new DaftarKendaraan("Wuling");
        
        
        Kendaraan ToyotaVios  = new Kendaraan("Vios");
        Kendaraan ToyotaLandCruiser = new Kendaraan("Land Cruiser");
        Toyota.head = ToyotaVios;
        Toyota.tail = ToyotaVios;
        Toyota.tail.next = ToyotaLandCruiser;
        Toyota.tail = ToyotaLandCruiser;
        
        Kendaraan MercedesSL200 = new Kendaraan("SL300");
        Kendaraan MercedesC200 = new Kendaraan("C200");
        Mercedes.head = MercedesSL200;
        Mercedes.tail = MercedesSL200;
        Mercedes.tail.next = MercedesC200;
        Mercedes.tail = MercedesC200;
        
        Kendaraan WulingCortez = new Kendaraan("Cortez");
        Kendaraan WulingAlmaz = new Kendaraan("Wuling Almaz");
        Wuling.head = WulingCortez;
        Wuling.tail = WulingCortez;
        Wuling.tail.next = WulingAlmaz;
        Wuling.tail = WulingAlmaz;
        
        
        daftarMerk.head = Toyota;
        daftarMerk.tail = Toyota;

        daftarMerk.tail.next = Mercedes;
        daftarMerk.tail =  Mercedes;
        
        daftarMerk.tail.next = Wuling;
        daftarMerk.tail =  Wuling;
        
        printAll(daftarMerk);
    }
    
}
